import sys
import os
from cravat import BaseAnnotator
from cravat import InvalidData

class CravatAnnotator(BaseAnnotator):

    def annotate (self, input_data, secondary_data):
        out = {}
        snp = secondary_data['dbsnp'][0]['snp'] 
        hugo = input_data['hugo']
        out['testcol'] = 'pharmgkb:{}:{}'.format(hugo, snp)
        return out

if __name__ == '__main__':
    annotator = CravatAnnotator(sys.argv)
    annotator.run()
